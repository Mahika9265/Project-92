import React from 'react';
import { StyleSheet, Text, View, SafeAreaView } from 'react-native';

<SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Welcome, how can we be of service?
      </Text>
      </SafeAreaView>

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'ffffed',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    fontColor: 'cbc3e3'
  },
});