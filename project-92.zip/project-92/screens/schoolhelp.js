import React from 'react';
import { StyleSheet, Text, View, SafeAreaView } from 'react-native';

<SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        What can we help you with?
      </Text>
      </SafeAreaView>

      const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: "pink",
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    fontColor: 'white'
  },
});